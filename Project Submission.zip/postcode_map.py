#!/usr/bin/env python
# -*- coding: utf-8 -*-

postcode_list = {'Berea':4001,'Carrington Heights':4001,'Essenwood':4001,'Glenwood':4001,'Musgrave':4001,'Overport':4091,
'Sherwood':4091,'Congella':4001,'Sparks':4091,'Springfield':4091,'Stamford Hill':4001,'Sydenham':4091,'Westridge':4319,
'Wiggins':4091}
